import './godot-sdk'
import './godot'
const exe = '/engine/godot';
const pack = '/engine/empty-tips.bin';
GODOTSDK.startGame(exe, pack)
