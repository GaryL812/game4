GameGlobal.__GODOT_DISABLE_WXGLX = true;
