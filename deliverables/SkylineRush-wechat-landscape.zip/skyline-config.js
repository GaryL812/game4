module.exports = {"appId":"touristappid","rewardAdUnitId":"","title":"云端飞奔 · SKYLINE RUSH"};
